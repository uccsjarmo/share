[cmdletBinding()]
param(
    [Parameter(Mandatory=$false,position=0)]
    [string]$Location = 'westeurope',

    [Parameter(Mandatory=$true,position=1)]
    [string]$DeploymentName,

    [Parameter(Mandatory=$false,position=2)]
    [switch]$ResourceGroupDeployment,

    [Parameter(Mandatory=$false,position=3)]
    [switch]$NetworkSecurityGroupDeployment,

    [Parameter(Mandatory=$false,position=4)]
    [switch]$VirtualNetworkDeployment,

    [Parameter(Mandatory=$false,position=5)]
    [switch]$VirtualNetworkSubnetDeployment,

    [Parameter(Mandatory=$false,position=6)]
    [switch]$ProximityPlacementGroupDeployment,

    [Parameter(Mandatory=$false,position=7)]
    [switch]$KeyVaultDeployment,

    [Parameter(Mandatory=$false,position=8)]
    [switch]$ManagedIdentiyDeployment,

    [Parameter(Mandatory=$false,position=9)]
    [switch]$FileShareDeployment,

    [Parameter(Mandatory=$false,position=10)]
    [switch]$NetworkInterfaceDeployment,

    [Parameter(Mandatory=$false,position=11)]
    [switch]$VirtualMachineDeployment,

    [Parameter(Mandatory=$false,position=12)]
    [switch]$LoadBalancerDeployment,

    [Parameter(Mandatory=$false,position=13)]
    [switch]$WebApplicationFirewallDeployment,

    [Parameter(Mandatory=$false,position=14)]
    [switch]$ApplicationGatewayDeployment,

    <# [Parameter(Mandatory=$false,position=15)]
    [switch]$DeployAll, #>

    [Parameter(Mandatory=$false,position=16)]
    [string]$PlaybookDir = '..\..\playbooks',

    [Parameter(Mandatory=$false,position=17)]
    [string]$ParametersDir = '.\parameters',

    [Parameter(Mandatory=$false,position=18)]
    [string]$ModulesDir = '..\..\modules',

    [Parameter(Mandatory=$false,position=19)]
    [switch]$DevTestLabFeatures
)

 #Deploy resource group artifacts if
if(($ResourceGroupDeployment -eq $true) -or ($DeployAll -eq $true)) {
    New-AzSubscriptionDeployment -Name $DeploymentName -TemplateParameterFile "$ParametersDir\resource-group.jsonc" -TemplateFile "$PlaybookDir\resource-group.bicep" -Location $Location
}

if(($NetworkSecurityGroupDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\network-security-group.jsonc"
    $resourceGroups = (Get-Content $json | ConvertFrom-Json).parameters.networkSecurityGroups.value
    foreach($resourceGroup in $resourceGroups.resourceGroup) {
        New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\network-security-groups.bicep" -ResourceGroupName $resourceGroup
    }
}

if(($VirtualNetworkDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\virtual-network.jsonc"
    $resource = (Get-Content $json | ConvertFrom-Json).parameters.virtualNetwork.value
    $resourceGroup = $resource.resourceGroup
    $vnet = Get-AzVirtualNetwork -Name $resource.name -ResourceGroupName $resourceGroup -ErrorAction Ignore
    if($null -eq $vnet) {
        New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$PlaybookDir\virtual-network.bicep" -ResourceGroupName $resourceGroup
    }
    else {
        $result = [ordered]@{
            'DeploymentName' = $DeploymentName
            'ResourceGroupName' = $resourceGroup
            'ProvisioningState' = 'Succeeded'
            'Timestamp' = (Get-Date).ToUniversalTime().ToString()
            'Mode' = 'Incremental'
        }
        Write-Output $result
    }
}

if(($VirtualNetworkSubnetDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\virtual-network.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.virtualNetwork.value.resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$PlaybookDir\virtual-network-subnet.bicep" -ResourceGroupName $resourceGroup
}

if(($ProximityPlacementGroupDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\proximity-placement-group.jsonc"
    $resourceGroups = (Get-Content $json | ConvertFrom-Json).parameters.proximityPlacementGroups.value
    foreach($resourceGroup in $resourceGroups.resourceGroup) {
        New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$PlaybookDir\proximity-placement-group.bicep" -ResourceGroupName $resourceGroup
    }
}

if(($KeyVaultDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\key-vault.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.keyVaults.value[0].resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\key-vaults.bicep" -ResourceGroupName $resourceGroup
}

if(($ManagedIdentiyDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\managed-identity.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.managedIdenties.value[0].resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\managed-identitys.bicep" -ResourceGroupName $resourceGroup
}

if(($FileShareDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\file-share.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.fileShares.value[0].resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\file-shares.bicep" -ResourceGroupName $resourceGroup
}

if(($NetworkInterfaceDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\network-interface.jsonc"
    $resourceGroups = (Get-Content $json | ConvertFrom-Json).parameters.networkInterfaces.value
    foreach($resourceGroup in $resourceGroups.resourceGroup) {
        New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$PlaybookDir\network-interface.bicep" -ResourceGroupName $resourceGroup
    }
}

if(($VirtualMachineDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\virtual-machine.jsonc"
    $resourceGroups = (Get-Content $json | ConvertFrom-Json).parameters.virtualMachines.value
    foreach($resourceGroup in $resourceGroups.resourceGroup) {
        New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$PlaybookDir\virtual-machine.bicep" -ResourceGroupName $resourceGroup
    }
}

if(($LoadBalancerDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\load-balancer.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.loadBalancers.value[0].resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\load-balancers.bicep" -ResourceGroupName $resourceGroup
}

if(($WebApplicationFirewallDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\web-application-firewall.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.webApplicationFirewallPolicies.value[0].resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\web-application-firewalls.bicep" -ResourceGroupName $resourceGroup
}

if(($ApplicationGatewayDeployment -eq $true) -or ($DeployAll -eq $true)) {
    $json =  "$ParametersDir\application-gateway.jsonc"
    $resourceGroup = (Get-Content $json | ConvertFrom-Json).parameters.applicationGateways.value[0].resourceGroup
    New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\application-gateways.bicep" -ResourceGroupName $resourceGroup
}

if($DevTestLabFeatures -eq $true) {
    $json =  "$ParametersDir\virtual-machine.jsonc"
    $resourceGroups = (Get-Content $json | ConvertFrom-Json).parameters.virtualMachines.value
    foreach($resourceGroup in $resourceGroups.resourceGroup) {
        New-AzResourceGroupDeployment -Name $DeploymentName -TemplateParameterFile $json -TemplateFile "$ModulesDir\dev-test-lab.bicep" -ResourceGroupName $resourceGroup
    }
}